youtube-dl-server
#################

Run the API server

.. program:: youtube-dl-server

.. option:: -p <port>, --port <port>

    The port the server will use. The default port is 9191

.. option:: --host HOST

    The host the server will use. The default host is localhost

.. option:: --number-processes NUMBER_PROCESSES

    The number of processes the server will use. The default is: 5

.. option:: -h , --help

    Display the help text

.. option:: --version

    Print the version of the server
