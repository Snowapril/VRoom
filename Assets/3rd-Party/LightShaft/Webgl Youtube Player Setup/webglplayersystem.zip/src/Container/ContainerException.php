<?php

namespace YoutubeDownloader\Container;

use Exception;

/**
 * Base interface representing a generic exception in a container.
 */
class ContainerException extends Exception
{
}
